from setuptools import setup, Extension
import pybind11

ext = Extension(
    "graph_executor_v2",
    sources=["src/bindings_min_api.cpp", "src/launch_table.cpp"],
    include_dirs=[pybind11.get_include(), "include"],
    language="c++",
    extra_compile_args=["/std:c++17"] if __import__('sys').platform=='win32' else ["-std=c++17"],
)

setup(
    name="graph_executor_v2",
    version="0.0.1",
    ext_modules=[ext],
)
    