import os, zipfile, glob
wheels = glob.glob(r"dist\graph_executor_v2-*.whl")
print("wheels:", wheels)
if wheels:
    with zipfile.ZipFile(wheels[0]) as z:
        pyds = [n for n in z.namelist() if n.endswith(".pyd")]
        print("pyd in wheel:", pyds)